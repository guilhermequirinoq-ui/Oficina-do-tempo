/* 1. Livro 3D: a rolagem muda os ângulos da capa e de uma folha. */
const secaoLivro = document.querySelector('#historiaLivro');
const livro = document.querySelector('#livro3d');
const legendaLivro = document.querySelector('#legendaLivro');
const movimentoReduzido = window.matchMedia('(prefers-reduced-motion: reduce)');

function limitar(valor, minimo, maximo) {
    return Math.min(Math.max(valor, minimo), maximo);
}

function atualizarLivro() {
    if (!livro || !secaoLivro) return;

    if (movimentoReduzido.matches) {
        livro.style.cssText = '';
        legendaLivro.textContent = 'Um livro para descobrir os ofícios antigos.';
        return;
    }

    const celular = window.innerWidth < 992;
    const topoSecao = secaoLivro.getBoundingClientRect().top + window.scrollY;
    const distancia = celular
        ? Math.max(secaoLivro.offsetHeight - window.innerHeight * 0.6, 300)
        : Math.max(secaoLivro.offsetHeight - window.innerHeight, 300);
    const progresso = limitar((window.scrollY - topoSecao) / distancia, 0, 1);
    const capa = limitar((progresso - 0.08) / 0.52, 0, 1);
    const folha = limitar((progresso - 0.53) / 0.42, 0, 1);

    livro.style.setProperty('--abertura-capa', (-158 * capa) + 'deg');
    livro.style.setProperty('--abertura-folha', (-148 * folha) + 'deg');
    livro.style.setProperty('--giro-livro', (-28 + 19 * progresso) + 'deg');
    livro.style.setProperty('--inclinacao-livro', (-6 + 6 * progresso) + 'deg');
    livro.style.setProperty('--deslocamento-livro', (progresso * (celular ? 58 : 80)) + 'px');
    livro.style.setProperty('--escala-livro', 1 - progresso * (celular ? 0.2 : 0.13));

    if (progresso < 0.3) {
        legendaLivro.textContent = 'Um pouco de história a cada página.';
    } else if (progresso < 0.7) {
        legendaLivro.textContent = 'Do campo às cidades: tudo começa com pessoas.';
    } else {
        legendaLivro.textContent = 'Saberes que transformaram a vida em sociedade.';
    }
}

// Atualiza uma vez por quadro, apenas quando existe uma mudança.
let quadroPendente = false;
function pedirAtualizacaoLivro() {
    if (quadroPendente) return;
    quadroPendente = true;
    window.requestAnimationFrame(function () {
        atualizarLivro();
        quadroPendente = false;
    });
}

if (livro) {
    window.addEventListener('scroll', pedirAtualizacaoLivro, { passive: true });
    window.addEventListener('resize', pedirAtualizacaoLivro);
    movimentoReduzido.addEventListener('change', pedirAtualizacaoLivro);
    atualizarLivro();
}

/* 2. Quiz: progresso, correção e botão para refazer. */
const formularioQuiz = document.querySelector('#formularioQuiz');

if (formularioQuiz) {
    const questoes = Array.from(formularioQuiz.querySelectorAll('.questao'));
    const aviso = document.querySelector('#avisoQuiz');
    const resultado = document.querySelector('#resultadoQuiz');

    function limparCorrecao() {
        questoes.forEach(function (questao) {
            questao.classList.remove('pendente');
            questao.querySelector('.feedback-questao').hidden = true;
            questao.querySelectorAll('.alternativa').forEach(function (alternativa) {
                alternativa.classList.remove('correta', 'incorreta');
            });
        });
        resultado.hidden = true;
        aviso.hidden = true;
    }

    function atualizarProgresso() {
        const respondidas = formularioQuiz.querySelectorAll('input:checked').length;
        document.querySelector('#textoProgresso').textContent = respondidas + ' de ' + questoes.length + ' respondidas';
        document.querySelector('#barraQuiz').style.width = (respondidas / questoes.length * 100) + '%';
        document.querySelector('#progressoQuiz').setAttribute('aria-valuenow', respondidas);
    }

    formularioQuiz.addEventListener('change', function () {
        limparCorrecao();
        atualizarProgresso();
    });

    formularioQuiz.addEventListener('submit', function (evento) {
        evento.preventDefault();
        limparCorrecao();
        const pendentes = questoes.filter(function (questao) {
            return !questao.querySelector('input:checked');
        });

        if (pendentes.length > 0) {
            aviso.textContent = 'Responda às ' + pendentes.length + ' questões que faltam antes de ver o resultado.';
            aviso.hidden = false;
            pendentes.forEach(function (questao) { questao.classList.add('pendente'); });
            pendentes[0].querySelector('input').focus();
            return;
        }

        let acertos = 0;
        questoes.forEach(function (questao) {
            const selecionada = questao.querySelector('input:checked');
            const correta = questao.querySelector('input[value="' + questao.dataset.resposta + '"]');
            const acertou = selecionada.value === questao.dataset.resposta;
            const feedback = questao.querySelector('.feedback-questao');

            if (acertou) {
                acertos++;
            } else {
                selecionada.closest('.alternativa').classList.add('incorreta');
            }
            correta.closest('.alternativa').classList.add('correta');
            const textoCorreto = correta.nextElementSibling.textContent;
            feedback.textContent = (acertou ? 'Acertou! ' : 'Resposta correta: ' + textoCorreto + ' ') + questao.dataset.explicacao;
            feedback.className = 'feedback-questao ' + (acertou ? 'acertou' : 'errou');
            feedback.hidden = false;
        });

        document.querySelector('#tituloResultado').textContent = acertos + ' de ' + questoes.length + ' acertos';
        document.querySelector('#mensagemResultado').textContent = acertos === questoes.length
            ? 'Muito bem! Você reconheceu os principais assuntos desta viagem pela Antiguidade.'
            : 'Confira as explicações em cada questão e revise os conteúdos. Depois, tente outra vez!';
        resultado.hidden = false;
        resultado.focus({ preventScroll: true });
        resultado.scrollIntoView({ behavior: movimentoReduzido.matches ? 'auto' : 'smooth', block: 'center' });
    });

    formularioQuiz.addEventListener('reset', function () {
        limparCorrecao();
        window.setTimeout(function () {
            atualizarProgresso();
            questoes[0].querySelector('input').focus();
        }, 0);
    });
}

/* 3. Contato demonstrativo. Não existe envio ou armazenamento de dados. */
const formularioContato = document.querySelector('#formularioContato');

if (formularioContato) {
    const campos = Array.from(formularioContato.querySelectorAll('input, textarea'));
    const confirmacao = document.querySelector('#resultadoContato');

    function validarCampo(campo) {
        const tamanhoMinimo = campo.minLength > 0 ? campo.minLength : 1;
        campo.setCustomValidity(campo.value.trim().length < tamanhoMinimo ? 'Preencha este campo corretamente.' : '');
        campo.setAttribute('aria-invalid', String(!campo.validity.valid));
    }

    campos.forEach(function (campo) {
        campo.addEventListener('input', function () {
            validarCampo(campo);
            confirmacao.hidden = true;
        });
    });

    formularioContato.addEventListener('submit', function (evento) {
        evento.preventDefault();
        campos.forEach(validarCampo);
        formularioContato.classList.add('was-validated');

        if (!formularioContato.checkValidity()) {
            campos.find(function (campo) { return !campo.validity.valid; }).focus();
            return;
        }

        confirmacao.hidden = false;
        confirmacao.focus();
    });
}
