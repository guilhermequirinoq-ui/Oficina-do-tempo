# Ofícios do Tempo — Trabalhos da Antiguidade

Trabalho escolar de **Guilherme e João Pedro**.

O site apresenta atividades de agricultores, artesãos, escribas, construtores,
comerciantes e soldados. São seis páginas HTML, um livro em CSS 3D que acompanha
a rolagem, oito exercícios com correção e uma página de materiais de estudo.

## Como abrir

Extraia o ZIP e abra `index.html` no navegador. Não precisa instalar programas
ou executar comandos para visualizar o site. Os arquivos de estilo, ícones,
scripts e imagens estão incluídos. Vídeos e links externos precisam de internet.

Para testar com um servidor local, se tiver Python instalado, execute
`python -m http.server 8000` dentro da pasta e abra `http://localhost:8000`.

## Arquivos

- `index.html`: apresentação, livro 3D, carrossel e atalhos.
- `sobre.html`: explicações e perguntas em accordion.
- `conteudos.html`: seis grupos de ofícios e suas explicações.
- `exercicios.html`: quiz de oito perguntas.
- `materiais.html`: vídeos, leituras, referências e créditos.
- `contato.html`: autoria e formulário demonstrativo.
- `css/estilo.css`: cores, layout, livro e ajustes para celular.
- `js/script.js`: rolagem do livro, quiz e validação do formulário.
- `imagens/`: fotografias, ilustrações e créditos em JSON.
- `vendor/`: Bootstrap e Bootstrap Icons originais, com suas licenças.

## Tecnologias e componentes

HTML5, CSS3 e JavaScript puro. Não há framework de aplicação, servidor de dados
ou etapa de compilação.

Bootstrap **5.3.8** original, distribuído pelo projeto oficial, e Bootstrap
Icons **1.11.3**. As bibliotecas estão salvas localmente para facilitar a abertura.

Componentes utilizados: Navbar, Collapse, Container, Row, Col, Carousel, Card,
Accordion, Forms, Buttons, Progress, Alert, List Group e Ratio.

Documentação: https://getbootstrap.com/docs/5.3/ e https://icons.getbootstrap.com/

## Como funciona o livro

O livro é formado por elementos HTML: capa, contracapa, lombada, bordas e folhas.
O CSS usa `perspective`, `preserve-3d`, `translateZ` e `rotateY` para criar volume.
O JavaScript calcula o progresso da rolagem na seção e altera variáveis CSS.
`requestAnimationFrame` limita as atualizações a um quadro por vez.

No computador, a área do livro usa `position: sticky`. No celular, o conteúdo
segue o fluxo normal. Quando a pessoa ativa a preferência por menos movimento,
o livro permanece fechado e a rolagem especial é desativada.

Esse livro é um recurso visual atual para apresentar o assunto. Ele não representa
um objeto utilizado igualmente por todas as civilizações antigas.

## Exercícios e formulário

O quiz exige que todas as perguntas sejam respondidas antes de corrigir. Mostra
a pontuação e as explicações, permite alterar respostas e refazer a atividade.
Nenhum resultado é enviado ou armazenado.

O contato é uma demonstração escolar. Ele valida nome, e-mail e mensagem no
navegador, mas **não envia nem armazena os dados**. A própria página informa isso.

## Como editar

Abra os arquivos em um editor como o Visual Studio Code. Os nomes já estão
preenchidos como Guilherme e João Pedro no rodapé de cada página, na capa do
livro e no contato. Para alterar textos, procure o trecho no arquivo HTML.

As cores principais ficam nas variáveis do início de `css/estilo.css`.
Os comentários numerados no CSS e no JavaScript ajudam a encontrar cada parte.

## Publicação no GitHub Pages

1. Crie um repositório no GitHub.
2. Envie o conteúdo desta pasta, mantendo `index.html` na raiz do repositório.
3. Acesse Settings → Pages.
4. Em Build and deployment, escolha Deploy from a branch.
5. Selecione a branch principal e a pasta raiz, depois salve.
6. Aguarde o GitHub informar o endereço publicado.

Referência: https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site

## Publicação na Vercel

1. Envie os arquivos para um repositório no GitHub.
2. Importe o repositório na Vercel.
3. Escolha o preset Other, sem comando de build.
4. Mantenha o diretório de saída na raiz do projeto.
5. Publique e aguarde a plataforma informar o endereço.

Referência: https://vercel.com/docs/deployments

Ao entregar a atividade, envie o link publicado e os nomes da dupla, conforme
a orientação do professor.

## Fontes e créditos

As referências completas também estão visíveis em `materiais.html`. Os textos são
sínteses educativas sobre contextos distintos, sem tratar as civilizações como iguais.

- The Met, maquete de celeiro com escribas: https://www.metmuseum.org/art/collection/search/545281
- The Met, carta cuneiforme: https://www.metmuseum.org/art/collection/search/325849
- The Met, conta de caravana: https://www.metmuseum.org/art/collection/search/325851
- The Met, ânfora atribuída a Exéquias: https://www.metmuseum.org/art/collection/search/250551
- The Met, soldado romano: https://www.metmuseum.org/art/collection/search/251842
- The Met, arte grega arcaica: https://www.metmuseum.org/essays/greek-art-in-the-archaic-period
- Egypt Exploration Society: https://www.ees.ac.uk/resource/life-at-work-on-the-nile.html
- Harvard Digital Giza: https://giza.fas.harvard.edu/lessons/daily-life-in-ancient-egypt/
- British Museum, exército romano: https://www.britishmuseum.org/exhibitions/legion-life-roman-army

As fotografias de peças do The Met são de domínio público / Open Access.
Os arquivos foram redimensionados e convertidos para WebP. `imagens/creditos.json`
registra identificação e fonte de cada objeto.

As duas ilustrações SVG são desenhos esquemáticos criados para este projeto.
Bootstrap e Bootstrap Icons têm licença MIT, preservada na pasta `vendor`.
